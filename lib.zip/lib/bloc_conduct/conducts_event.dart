part of 'conducts_bloc.dart';

@immutable
sealed class ConductsEvent {}

class GetContactEvent extends ConductsEvent {}
